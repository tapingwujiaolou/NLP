# 这是一个示例 Python 脚本。

# 按 Shift+F10 执行或将其替换为您的代码。
# 按 双击 Shift 在所有地方搜索类、文件、工具窗口、操作和设置。


import os
import jieba
import warnings
warnings.filterwarnings('ignore')
#%%
novel_path = "E:/Learn/WORD2VEC/金庸小说精校版/"
data_path = "E:/Learn/WORD2VEC/"
#%%
# 加载停用词表
stop_words_file = open(data_path + "stop_words.txt", 'r')
stop_words = list()
for line in stop_words_file.readlines():
    line = line.strip()   # 去掉每行末尾的换行符
    stop_words.append(line)
stop_words_file.close()
print(len(stop_words))
print(stop_words[300:320])
#%% md
#分词前在词库中加入人物名称、武功名称、门派名称
#%%
# 导入金庸小说人物
people_names_file = open(data_path + "金庸小说全人物.txt", 'r')
people_names = list()
for line in people_names_file.readlines():
    line = line.strip()   # 去掉每行末尾的换行符
    jieba.add_word(line)
    people_names.append(line)
stop_words_file.close()
print(len(people_names))
#%%
# 导入金庸小说武功
kungfu_names_file = open(data_path + "金庸小说全武功.txt", 'r')
kungfu_names = list()
for line in kungfu_names_file.readlines():
    line = line.strip()   # 去掉每行末尾的换行符
    jieba.add_word(line)
    kungfu_names.append(line)
stop_words_file.close()
print(len(kungfu_names))
#%%
# 导入金庸小说门派
sect_names_file = open(data_path + "金庸小说全门派.txt", 'r')
sect_names = list()
for line in sect_names_file.readlines():
    line = line.strip()   # 去掉每行末尾的换行符
    jieba.add_word(line)
    sect_names.append(line)
stop_words_file.close()
print(len(sect_names))
#%%
novel_names = list(os.listdir(novel_path))
#%%
seg_novel = []
for novel_name in novel_names:
    novel = open(novel_path + novel_name, 'r', encoding='utf-8-sig')
    print("Waiting for {}...".format(novel_name))
    line = novel.readline()
    forward_rows = len(seg_novel)
    while line:
        line_1 = line.strip()
        outstr = ''
        line_seg = jieba.cut(line_1, cut_all=False)
        for word in line_seg:
            if word not in stop_words:
                if word != '\t':
                    if word[:2] in people_names:
                        word = word[:2]
                    outstr += word
                    outstr += " "
        if len(str(outstr.strip())) != 0:
            seg_novel.append(str(outstr.strip()).split())
        line = novel.readline()
    print("{} finished，with {} Row".format(novel_name, (len(seg_novel) - forward_rows)))
    print("-" * 40)
print("-" * 40)
print("-" * 40)
print("All finished，with {} Row".format(len(seg_novel)))
#%%
for line in seg_novel[30000:30010]:
    print(line)
#%%
import gensim.models as w2v
#%%
model = w2v.Word2Vec(sentences=seg_novel, vector_size=200, window=5, min_count=5, workers=4, sg=1)
#%%
# 寻找相似关系
def find_relation(a, b, c):
    d, _ = model.wv.most_similar(positive=[c, b], negative=[a])[0]
    print (c,d)
#%%
find_relation("武当派","张三丰","天地会")
#%%
print(model.wv.most_similar(u"张无忌", topn=10))
#%%
model.save(data_path + 'all_skip_gram.model')
#%%
model = w2v.Word2Vec.load(data_path + 'all_skip_gram.model')
#%%
print(model.wv.similarity('张无忌', '周芷若'))
print(model.wv.similarity('张无忌', '赵敏'))
#%%
print(model.wv.most_similar("韦小宝", topn=10))
#%%
model.wv.most_similar("王重阳", topn=10)
#%%
print(model.wv.similarity('韦小宝', '阿珂'))
print(model.wv.similarity('韦小宝', '双儿'))
print(model.wv.similarity('韦小宝', '建宁公主'))
print(model.wv.similarity('韦小宝', '苏荃'))
print(model.wv.similarity('韦小宝', '沐剑屏'))
print(model.wv.similarity('韦小宝', '曾柔'))
print(model.wv.similarity('韦小宝', '方怡'))
#%%
find_relation("杨过","小龙女","乔峰")
# 访问 https://www.jetbrains.com/help/pycharm/ 获取 PyCharm 帮助
